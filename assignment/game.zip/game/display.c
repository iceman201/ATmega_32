/**
    @brief Display module for pong game.
*/

#include "display.h"
